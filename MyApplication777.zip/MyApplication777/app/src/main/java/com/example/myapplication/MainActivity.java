package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edt_consumo,edt_couvertartistico,edt_dividir,edt_servico,edt_conta_total,edt_valor_pessoa;
    Button bt_calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt_consumo = (EditText) findViewById(R.id.edt_consumo);
        edt_couvertartistico = (EditText) findViewById(R.id.edt_couvertartistico);
        edt_dividir = (EditText) findViewById(R.id.edt_dividir);
        edt_servico = (EditText) findViewById(R.id.edt_servico);
        edt_conta_total = (EditText) findViewById(R.id.edt_conta_total);
        edt_valor_pessoa = (EditText) findViewById(R.id.edt_valor_pessoa);

        bt_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double ctotal;
                double couvert;
                double dividirpor;
                double contatotal;
                double valorporpessoa;
                double taxadeservico;

                valorporpessoa=contatotal/dividirpor;
                taxadeservico=ctotal;
                contatotal=ctotal+couvert+taxadeservico;

                ctotal=Double.parseDouble(edt_consumo.getText().toString());
                couvert=Double.parseDouble(edt_couvertartistico.getText().toString());
                dividirpor=Double.parseDouble(edt_dividir.getText().toString());
            }
        });
    }
}
