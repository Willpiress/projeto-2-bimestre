package com.tarefa.myapplicationprojeto2;

import android.app.Dialog;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt_num1;
    EditText edt_num2;
    Button bt_som;
    Button bt_sub;
    Button bt_mult;
    Button bt_div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setContentView(R.layout.tela2);

        edt_num1 = (EditText) findViewById(R.id.edt_num1);
        edt_num2 = (EditText) findViewById(R.id.edt_num2);
        bt_som = (Button) findViewById(R.id.bt_som);
        bt_sub = (Button) findViewById(R.id.bt_sub);
        bt_mult = (Button) findViewById(R.id.bt_mult);
        bt_div = (Button) findViewById(R.id.bt_div);

        bt_som.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(edt_num1.getText().toString());
                double num2 = Double.parseDouble(edt_num2.getText().toString());
                double soma = num1+num2;
                double subtracao = num1-num2;
                double multiplicacao = num1*num2;
                double divisao = num1/num2;
                AlertDialog.Builder dialogo = new
                AlertDialog.Builder(MainActivity.this);
                dialogo.setTitle("Resultado: ");
                dialogo.setTitle("A soma é: "+soma);
                dialogo.setTitle("A subtração é: "+subtracao);
                dialogo.setTitle("A multiplicação é: "+multiplicacao);
                dialogo.setTitle("A divisão é: "+divisao);
                dialogo.setNeutralButton("OK",null);
                dialogo.show();
            }
        });

    }
}
